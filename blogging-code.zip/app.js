require('dotenv').config();
const Path = require('path');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 8000;
const cookieParser = require('cookie-parser');
const { checkForAuthenticationCookie } = require('./middlewares/authentication');

const mongoose = require('mongoose');
const userRouter = require('./routes/user');
const blogRouter = require('./routes/blog');
const apiUserRouter = require('./routes/api-user');
const apiBlogRouter = require('./routes/api-blog');
const apiCommentRouter = require('./routes/api-comment');
app.set('view engine', 'ejs');
app.set('views', Path.resolve(__dirname, 'views'));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(Path.resolve(__dirname, 'public')));
app.use(cookieParser());
app.use(checkForAuthenticationCookie('token'));

mongoose
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/blogging_app')
  .then(() => {
    console.log('MongoDB connected successfully');
  })
  .catch((error) => {
    console.error('MongoDB connection failed:', error.message);
  });

app.get('/', (req, res) => {
  res.render('home',{ user: req.user || null});
});

app.use('/user', userRouter);
app.use('/api/user', apiUserRouter);
app.use('/blog',blogRouter);
app.use('/api/blog', apiBlogRouter);
app.use('/api/comment', apiCommentRouter);
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
